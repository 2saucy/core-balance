const DietPage = () => {
    return (
        <div>
            <h1>Diet Page</h1>
        </div>
    );
}
 
export default DietPage;